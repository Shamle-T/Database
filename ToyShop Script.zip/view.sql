CREATE VIEW supply_view_new
AS SELECT product_id AS 'item_id',price,cost,price - cost AS 'profit', CONCAT(business_name,' (',phone_number,', ',website_url,' )')AS 'primary_supplier_details'
FROM product INNER JOIN supplier ON product.supplier_id = supplier.supplier_id;
