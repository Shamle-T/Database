--Query 1 (Product Search)
SELECT product_id AS 'item_id', item_name, '$' + CAST (price AS CHAR(6)) AS price, stock
FROM product
WHERE price LIKE '%.99' AND stock < 40
ORDER BY price DESC;

--Query 2 (Unpopular Items)
SELECT product_id AS 'item_id', item_name, stock, business_name + ' (' + phone_number + ', '+ website_url + ' )' AS 'primary_supplier_details' 
FROM supplier INNER JOIN product
ON supplier.supplier_id = product.supplier_id
WHERE product_id NOT IN ( SELECT DISTINCT product_id FROM order_detail) 
ORDER BY stock DESC;

--Query 3 (Special Event Summary)
SELECT CONCAT('There are ',(COUNT(event_id)),' orders during ',special_event.name,' that have ',discount_percent,'% off.') AS 'event_orders'
FROM special_event 
GROUP BY special_event.name,discount_percent 
ORDER BY name ASC, discount_percent DESC;


--Query 4 (Monthly Orders)
SELECT YEAR(order_date) AS 'year',FORMAT(order_date, 'MMMM') AS 'month', COUNT(*) AS 'number_of_orders' FROM invoice
GROUP BY YEAR(order_date), FORMAT(order_date,'MMMM')
ORDER BY YEAR(order_date), FORMAT(Order_date,'MMMM')

--Query 5 (Referrals)
SELECT a1.customer_id, CONCAT(a1.first_name, ' ', a1.last_name) AS 'customer_name', COUNT(b1.referrer) AS 'no_of_customer' FROM customer AS a1
JOIN customer AS b1 ON b1.referrer = a1.customer_id
GROUP BY a1.customer_id, CONCAT(a1.first_name, ' ', a1.last_name)
HAVING COUNT(b1.referrer) >= 2;

--Query 6 (Items per customer)
SELECT customer.customer_id, CONCAT(first_name, ' ', last_name) AS 'customer_name', ISNULL(SUM(quantity), 0) AS 'items_ordered' FROM customer
LEFT JOIN invoice ON customer.customer_id = invoice.customer_id
LEFT JOIN order_detail ON order_detail.invoice_id = invoice.invoice_id
GROUP BY customer.customer_id, CONCAT(first_name, ' ', last_name);

--Query 7 (Electronics count) 
SELECT invoice_id AS '�rder_id', SUM(quantity * price) AS 'total_price', COUNT(order_detail.product_id) AS 'electronic_count' FROM order_detail
JOIN product ON order_detail.product_id = product.product_id
JOIN category_item ON category_item.product_id =product.product_id
JOIN category ON category_item.category_id = category.category_id
WHERE category.category_name = 'Electronic Gadgets'
GROUP BY invoice_id

--Query 8 (Cohabitation)

SELECT CONCAT(customer.first_name, ' ', customer.last_name) AS 'customer_name', address.address_1 AS 'customer_address' FROM customer 
INNER JOIN address ON customer.customer_id = address.customer_id
INNER JOIN address AS a ON a.address_id = a.address_id
WHERE address.address_name = 'Home'
ORDER�BY�address.address_1;



-- Query 9 (Bulky orders)
SELECT invoice.invoice_id AS 'order_id', address.address_1 AS 'delivery_address', COUNT(order_detail.product_id) AS 'items_ordered' FROM invoice
JOIN order_detail ON invoice.invoice_id = order_detail.invoice_id
JOIN address ON invoice.delivery_address = address.address_id
GROUP BY invoice.invoice_id, address.address_1
HAVING COUNT(order_detail.product_id) > (SELECT AVG(item_count) 
FROM (SELECT COUNT(product_id) AS item_count FROM order_detail GROUP BY invoice_id ) AS avg_items_per_order)
ORDER BY 'items_ordered' DESC;
