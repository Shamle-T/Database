CREATE VIEW order_view_new AS
SELECT invoice.invoice_id, invoice.customer_id,billing_address AS 'billing_addr_id',
       delivery_address AS 'delivery_addr_id',customer.first_name AS 'customer_name',billing1.address_name AS
	   'billing_address',delivery1.address_name AS 'delivery_address',quantity * price AS 'purchase_total'
FROM invoice INNER JOIN customer ON invoice.customer_id = customer.customer_id
INNER JOIN Address AS billing1 ON invoice.billing_address = billing1.address_id
INNER JOIN Address AS delivery1 ON invoice.delivery_address = delivery1.address_id
INNER JOIN order_detail ON invoice.invoice_id = order_detail.invoice_id
INNER JOIN product ON order_detail.product_id = product.product_id;